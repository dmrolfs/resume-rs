# Application brand assets

Each app folder includes:
- app-icon-1024.png
- menu-bar-icon.png
- favicon-256.png and favicon-{16,32,48,64,128}.png
- favicon.ico (multi-size)
- palette.json and palette.css

The icons are raster crops from the concept sheet, not editable vector source files.
Menu-bar artwork is supplied in color; native macOS menu-bar use typically calls for
a monochrome template/redrawn asset appropriate to the app framework.
